#!/usr/bin/env python3
"""
Voice Macro — DaVinci Resolve Workflow Integration script

Three knobs (Depth, Presence, Control) that compute Fairlight EQ + dynamics
settings for turning a cheap mic closer to a broadcast voice.

Install:
  Copy this file into:
  Mac:     ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/
  Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility\
  Linux:   ~/.local/share/DaVinciResolve/Fusion/Scripts/Utility/

Then: Workspace > Scripts > VoiceMacro

Limitations (Resolve 19–21 scripting API):
- Cannot directly set individual Fairlight EQ band gains or dynamics parameters.
- Can list Fairlight presets and apply them to the current timeline.
- Use the printed numbers to dial the settings by hand, then save as a preset.
"""

import sys
import math

# Resolve injects these when the script is run from the menu
try:
    resolve = resolve  # noqa: F821
    project = project  # noqa: F821
    fusion = fusion    # noqa: F821
    bmd = bmd          # noqa: F821
except NameError:
    print("Run this script from inside DaVinci Resolve (Workspace > Scripts).")
    sys.exit(1)


def clip01(v):
    return max(0.0, min(1.0, float(v)))


def map_knobs(depth, presence, control):
    d = clip01(depth)
    p = clip01(presence)
    c = clip01(control)

    return {
        "hpf_hz": 70,
        "body_hz": 140,
        "body_q": 0.8,
        "body_db": round(4.5 * (d ** 0.8), 1),
        "mud_hz": 320,
        "mud_q": 1.0,
        "mud_db": round(-2.5 * d, 1),
        "pres_hz": 3200,
        "pres_q": 1.0,
        "pres_db": round(4.0 * p, 1),
        "air_hz": min(11000, int(0.45 * 48000)),
        "air_db": round(2.5 * (1 - math.exp(-2.5 * p)), 1),
        # Dynamics
        "exp_ratio": round(1.0 + 2.5 * c, 1),
        "exp_above_floor_db": round(8 + 12 * c, 0),
        "comp_thr_db": round(-18 - 10 * c, 1),
        "comp_ratio": round(1.5 + 2.5 * c, 1),
        "comp_knee_db": round(6 - 4 * c, 0),
        "makeup_db": round(2.0 + 6.0 * c, 1),
        "limit_ceiling_db": -1.0,
    }


def build_recipe(params):
    lines = [
        "=== VOICE MACRO FAIRLIGHT RECIPE ===",
        "",
        "EQ (Fairlight 6-band or Channel EQ):",
        f"  High-pass: {params['hpf_hz']} Hz  (fixed)",
        f"  Body:      {params['body_hz']} Hz, Q {params['body_q']}, {params['body_db']:+.1f} dB",
        f"  Mud cut:   {params['mud_hz']} Hz, Q {params['mud_q']}, {params['mud_db']:+.1f} dB",
        f"  Presence:  {params['pres_hz']} Hz, Q {params['pres_q']}, {params['pres_db']:+.1f} dB",
        f"  Air:       high shelf {params['air_hz']} Hz, {params['air_db']:+.1f} dB",
        "",
        "Dynamics:",
        f"  Expander:  ratio {params['exp_ratio']:.1f}:1, threshold ~noise floor + {params['exp_above_floor_db']:.0f} dB",
        f"  Compressor: thr {params['comp_thr_db']:.1f} dBFS, ratio {params['comp_ratio']:.1f}:1, knee {params['comp_knee_db']:.0f} dB",
        f"  Makeup:    {params['makeup_db']:+.1f} dB",
        f"  Limiter:   ceiling {params['limit_ceiling_db']:.1f} dBFS",
        "",
        "Suggested order: HPF → Expander → EQ → De-esser (manual) → Compressor → Limiter",
        "Match loudness (within ~0.5 LU) before judging the result.",
    ]
    return "\n".join(lines)


def main():
    ui = fusion.UIManager
    disp = bmd.UIDispatcher(ui)

    # Knobs as sliders (UIManager has limited rotary support)
    win = disp.AddWindow(
        {
            "ID": "VoiceMacro",
            "WindowTitle": "Voice Macro",
            "Geometry": [200, 200, 480, 620],
        },
        ui.VGroup(
            [
                ui.Label({"Text": "Voice Macro — cheap mic → broadcast", "Weight": 0, "Alignment": {"AlignHCenter": True}}),
                ui.Label({"Text": "Depth", "Weight": 0}),
                ui.Slider({"ID": "depth", "Value": 45, "Minimum": 0, "Maximum": 100}),
                ui.Label({"ID": "depth_val", "Text": "45", "Weight": 0}),
                ui.Label({"Text": "Presence", "Weight": 0}),
                ui.Slider({"ID": "presence", "Value": 40, "Minimum": 0, "Maximum": 100}),
                ui.Label({"ID": "pres_val", "Text": "40", "Weight": 0}),
                ui.Label({"Text": "Control", "Weight": 0}),
                ui.Slider({"ID": "control", "Value": 35, "Minimum": 0, "Maximum": 100}),
                ui.Label({"ID": "ctrl_val", "Text": "35", "Weight": 0}),
                ui.Button({"ID": "calc", "Text": "Calculate Fairlight Recipe"}),
                ui.TextEdit(
                    {
                        "ID": "recipe",
                        "ReadOnly": True,
                        "PlainText": "Move the knobs and click Calculate.",
                        "Weight": 1,
                    }
                ),
                ui.HGroup(
                    [
                        ui.Button({"ID": "list_presets", "Text": "List Fairlight Presets"}),
                        ui.Button({"ID": "apply", "Text": "Apply Selected Preset"}),
                    ]
                ),
                ui.LineEdit({"ID": "preset_name", "PlaceholderText": "Preset name to apply"}),
                ui.Button({"ID": "close", "Text": "Close"}),
            ]
        ),
    )

    def update_labels(ev):
        win.Find("depth_val").Text = str(int(win.Find("depth").Value))
        win.Find("pres_val").Text = str(int(win.Find("presence").Value))
        win.Find("ctrl_val").Text = str(int(win.Find("control").Value))

    def on_calc(ev):
        d = win.Find("depth").Value / 100.0
        p = win.Find("presence").Value / 100.0
        c = win.Find("control").Value / 100.0
        params = map_knobs(d, p, c)
        recipe = build_recipe(params)
        win.Find("recipe").PlainText = recipe

    def on_list(ev):
        try:
            presets = resolve.GetFairlightPresets()
            if not presets:
                text = "No Fairlight presets found (or API not available).\nSave one in Fairlight > Presets Library first."
            else:
                text = "Available Fairlight presets:\n" + "\n".join(str(x) for x in presets)
            win.Find("recipe").PlainText = text
        except Exception as e:
            win.Find("recipe").PlainText = f"Error listing presets: {e}"

    def on_apply(ev):
        name = win.Find("preset_name").Text.strip()
        if not name:
            win.Find("recipe").PlainText = "Enter a preset name first."
            return
        try:
            proj = resolve.GetProjectManager().GetCurrentProject()
            ok = proj.ApplyFairlightPresetToCurrentTimeline(name)
            win.Find("recipe").PlainText = f"Apply '{name}': {'success' if ok else 'failed (preset missing or API limitation)'}"
        except Exception as e:
            win.Find("recipe").PlainText = f"Error applying preset: {e}"

    win.On.depth.ValueChanged = update_labels
    win.On.presence.ValueChanged = update_labels
    win.On.control.ValueChanged = update_labels
    win.On.calc.Clicked = on_calc
    win.On.list_presets.Clicked = on_list
    win.On.apply.Clicked = on_apply
    win.On.close.Clicked = lambda ev: disp.ExitLoop()
    win.On.VoiceMacro.Close = lambda ev: disp.ExitLoop()

    win.Show()
    disp.RunLoop()
    win.Hide()


if __name__ == "__main__":
    main()
