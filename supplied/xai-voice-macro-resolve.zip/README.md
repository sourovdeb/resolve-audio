# Voice Macro — Resolve Workflow Integration

A three-knob panel that calculates Fairlight EQ + dynamics settings
so a cheap mic can be pushed toward a broadcast voice using Resolve’s own tools.

## Install

Copy `VoiceMacro.py` into Resolve’s Scripts folder:

- **macOS**: `~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/`
- **Windows**: `%APPDATA%\Blackmagic Design\DaVinci Resolve\Fusion\Scripts\Utility\`
- **Linux**: `~/.local/share/DaVinciResolve/Fusion/Scripts/Utility/`

Restart Resolve (or use Workspace > Scripts > Refresh Scripts List).

Run from **Workspace > Scripts > VoiceMacro**.

## What it does

- Depth, Presence, Control knobs (sliders)
- Calculates concrete numbers for:
  - High-pass
  - Body / Mud / Presence / Air EQ
  - Expander, Compressor, Makeup, Limiter
- Lists and applies existing Fairlight presets (Resolve 20.2+)

## What it cannot do

The Resolve scripting API does not expose individual Fairlight EQ band gains or dynamics parameters.
You type the calculated values into Fairlight yourself, then save them as a preset for later recall.

A true real-time processing plugin would be a VST3 (JUCE) that Resolve hosts on the Fairlight page.
