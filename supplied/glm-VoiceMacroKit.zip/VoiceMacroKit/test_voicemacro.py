"""
test_voicemacro.py - offline test suite (runs anywhere with Python 3.8+).

Two tiers:
  Tier 1 (always): panel logic + chain math, stdlib only.
  Tier 2 (if numpy/scipy present): reference DSP sanity from
  voice_macro.py - knob-0 transparency, monotonicity, limiter ceiling.

Run:  python test_voicemacro.py
"""

import os
import sys
import math

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, bool(ok), detail))
    print("[%s] %s%s" % ("PASS" if ok else "FAIL", name,
                         (": " + detail) if detail else ""))


# ---------------------------------------------------------------------------
# Tier 1: chain math + panel logic (stdlib only)
# ---------------------------------------------------------------------------
def test_chain_math():
    import chain_math as cm
    P = cm.map_knobs(0.5, 0.5, 0.5)
    check("map_knobs returns all keys", len(P) >= 20, "%d params" % len(P))

    # knobs at 0 -> all dynamic gains 0, eq flat
    P0 = cm.map_knobs(0, 0, 0)
    check("knob-0 transparency (eq gains all 0)",
          P0["body_db"] == 0 and P0["mud_db"] == 0
          and P0["pres_db"] == 0 and P0["air_db"] == 0)
    check("knob-0 comp ratio 1:1", P0["comp_ratio"] == 1.0)
    check("knob-0 exp ratio 1:1", P0["exp_ratio"] == 1.0)
    check("knob-0 makeup 0 dB", P0["makeup_db"] == 0.0)

    # monotonicity: more depth -> more body, more cut, never sign flips
    last = -1
    mono = True
    for d in [0, 0.25, 0.5, 0.75, 1.0]:
        body = cm.map_knobs(d, 0, 0)["body_db"]
        if body < last:
            mono = False
        last = body
    check("depth monotonic body boost", mono)

    # recipe completeness
    r = cm.fairlight_recipe(0.6, 0.6, 0.4)
    for key in ("eq", "deesser", "dynamics", "voice_isolation",
                "noise_reduction", "_meta"):
        if key not in r:
            check("recipe has key %s" % key, False)
            return
    check("recipe sections present", True)
    check("recipe expander threshold tracks noise floor",
          abs(r["dynamics"]["expander"]["threshold_db"] - (-50.0 + 6.0)) < 1e-9)

    # fs clamps (44.1k safety)
    P44 = cm.map_knobs(1, 1, 1, fs=44100)
    check("air shelf clamped at 44.1k", P44["air_hz"] <= 0.45 * 44100,
          "%g <= %g" % (P44["air_hz"], 0.45 * 44100))

    # named settings distinct
    ns = cm.named_settings()
    check("named settings: 3 presets", len(ns) == 3 and
          ns["Light"] != ns["Strong"])


def test_panel_logic():
    import importlib.util
    # import without triggering the Resolve-only code paths
    spec = importlib.util.find_spec("voice_macro_panel")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    logic = mod.PanelLogic()

    logic.set_knobs(0.7, 0.2, 0.9)
    check("set_knobs clamps + stores", logic.knobs() == (0.7, 0.2, 0.9))
    logic.set_knobs(2.0, -1.0, 0.5)
    check("set_knobs clamps out-of-range", logic.knobs() == (1.0, 0.0, 0.5))

    k = logic.apply_named("Strong")
    check("apply_named Strong", k == (1.0, 1.0, 0.5))
    check("apply_named unknown -> None", logic.apply_named("Nope") is None)

    s = logic.summary_line()
    check("summary_line is a short string", 0 < len(s) < 80, s)

    vi = logic.voice_isolation_setting()
    check("VI setting dict shape",
          set(vi) == {"isEnabled", "amount"} and 0 <= vi["amount"] <= 100, str(vi))

    import chain_math as cm
    txt = logic.recipe_text(cm)
    lines = txt.count("\n") + 1
    check("recipe_text renders multi-line", lines >= 6, "%d lines" % lines)
    for token in ("HP 70", "body", "DE-ESSER", "comp", "limiter"):
        if token not in txt:
            check("recipe_text contains '%s'" % token, False)
            return
    check("recipe_text covers all stages", True)


# ---------------------------------------------------------------------------
# Tier 2: reference DSP (numpy/scipy)
# ---------------------------------------------------------------------------
def test_dsp():
    try:
        import numpy as np
        from scipy import signal
    except ImportError:
        print("[SKIP] numpy/scipy not installed - DSP tier skipped")
        return
    import voice_macro as vm

    fs = 48000
    t = np.arange(int(fs * 2)) / fs
    rng = np.random.RandomState(7)
    x = (0.3 * np.sin(2 * np.pi * 110 * t)            # fundamental-ish
         + 0.2 * np.sin(2 * np.pi * 220 * t)
         + 0.05 * rng.randn(len(t)))                    # "noise"

    y0 = vm.process(x, fs, 0, 0, 0)
    resid = float(np.max(np.abs(y0 - vm_lim_hpf(x, fs))))
    check("DSP knob-0 == HPF-only (transparency)", resid < 1e-9,
          "residual %g" % resid)

    # limiter ceiling holds under +20 dB hot input
    hot = x * 10.0
    y = vm.process(hot, fs, 0.5, 0.5, 0.5)
    peak_db = 20 * math.log10(float(np.max(np.abs(y))) + 1e-12)
    check("limiter holds -1 dBFS ceiling", peak_db <= -0.9,
          "peak %.2f dBFS" % peak_db)

    # monotonic: body band energy grows with depth
    def band_energy(sig, lo, hi):
        sos = signal.butter(2, [lo, hi], "bandpass", fs=fs, output="sos")
        return float(np.mean(signal.sosfilt(sos, sig) ** 2))
    e_low = [band_energy(vm.process(x, fs, d, 0, 0), 100, 200)
             for d in (0.0, 0.5, 1.0)]
    check("depth raises 100-200 Hz energy", e_low[0] < e_low[1] < e_low[2],
          "%.4f < %.4f < %.4f" % tuple(e_low))

    # presence raises 2-4.5k energy
    e_pr = [band_energy(vm.process(x, fs, 0, p, 0), 2000, 4500)
            for p in (0.0, 1.0)]
    check("presence raises 2-4.5 kHz energy", e_pr[0] < e_pr[1])


def vm_lim_hpf(x, fs):
    """HPF-only reference (what knob-0 should equal)."""
    from scipy import signal
    return signal.sosfilt(signal.butter(2, 70.0, "highpass", fs=fs,
                                        output="sos"), x)


def main():
    print("VoiceMacroKit offline test suite")
    print("=" * 60)
    test_chain_math()
    test_panel_logic()
    test_dsp()
    print("=" * 60)
    n_fail = sum(1 for _, ok, _ in RESULTS if not ok)
    print("%d checks, %d failed" % (len(RESULTS), n_fail))
    return 1 if n_fail else 0


if __name__ == "__main__":
    sys.exit(main())
