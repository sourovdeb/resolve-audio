"""
make_presets.py - generate the Fairlight preset JSON files (the "save as
preset" data for the kit's three named settings), plus a copy-paste
recipe sheet for dialling into Resolve by hand.

Output (into ./presets/):
    vm_light.json, vm_medium.json, vm_strong.json   - machine-readable
    RECIPE_SHEET.txt                                 - human copy-paste table

These JSONs are for YOUR reference/automation tooling and for the panel
(read-only). Resolve's own preset save (right-click > save preset in the
EQ/Dynamics windows) is still the one that binds to the UI.
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chain_math as cm

FLOOR_DB = -50.0   # typical quiet-room noise floor; adjust per source


def preset_row(name, knobs, floor_db=FLOOR_DB):
    d, p, c = knobs
    r = cm.fairlight_recipe(d, p, c, source_floor_db=floor_db)
    r["_meta"]["preset_name"] = name
    return r


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(here, "presets")
    os.makedirs(out_dir, exist_ok=True)

    presets = cm.named_settings()
    files = []
    for name, knobs in presets.items():
        row = preset_row(name, knobs)
        fname = "vm_%s.json" % name.lower()
        path = os.path.join(out_dir, fname)
        with open(path, "w") as fh:
            json.dump(row, fh, indent=2)
        files.append(path)
        print("wrote", path)

    # copy-paste recipe sheet
    sheet = [("=" * 72),
             "VOICE MACRO - FAIRLIGHT SETTINGS SHEET (copy/paste while "
             "dialling in)",
             "=" * 72,
             "Noise-floor assumption: %g dBFS (edit make_presets.py if "
             "your room is noisier)" % FLOOR_DB, ""]
    for name, knobs in presets.items():
        r = preset_row(name, knobs)
        eq, deess, dyn = r["eq"], r["deesser"], r["dynamics"]
        comp, exp = dyn["compressor"], dyn["expander"]
        sheet += [
            "---- %s   (depth %s | presence %s | control %s) ----"
            % (name.upper(), knobs[0], knobs[1], knobs[2]),
            "EQ:       HP %g Hz | body %g Hz Q%g %+g dB | mud %g Hz Q%g %+g dB"
            % (eq["band1_highpass_hz"],
               eq["band2_body"]["freq_hz"], eq["band2_body"]["q"], eq["band2_body"]["gain_db"],
               eq["band3_mud"]["freq_hz"], eq["band3_mud"]["q"], eq["band3_mud"]["gain_db"]),
            "          presence %g Hz Q%g %+g dB | air shelf %g Hz %+g dB"
            % (eq["band4_presence"]["freq_hz"], eq["band4_presence"]["q"], eq["band4_presence"]["gain_db"],
               eq["band5_airs"]["freq_hz"], eq["band5_airs"]["gain_db"]),
            "DE-ESSER: centre %g Hz | %s | expect ~%g dB on 's'"
            % (deess["freq_hz"], deess["mode"], deess["expected_reduction_db"]),
            "DYNAMICS: expander thr %g dB, %g:1, atk %g ms, rel %g ms, max red %g dB"
            % (exp["threshold_db"], exp["ratio"], exp["attack_ms"],
               exp["release_ms"], exp["max_reduction_db"]),
            "          comp thr %g dB, %g:1, atk %g ms, rel %g ms, makeup %+g dB"
            % (comp["threshold_db"], comp["ratio"], comp["attack_ms"],
               comp["release_ms"], comp["makeup_db"]),
            "          limiter ceiling %g dBFS" % dyn["limiter"]["ceiling_dbfs"],
            "VOICE ISO: %s (amount %g%%)"
            % ("on" if r["voice_isolation"]["enable"] else "off",
               r["voice_isolation"]["amount_pct"]),
            "",
        ]
    sheet_path = os.path.join(out_dir, "RECIPE_SHEET.txt")
    with open(sheet_path, "w") as fh:
        fh.write("\n".join(sheet) + "\n")
    print("wrote", sheet_path)
    return files


if __name__ == "__main__":
    main()
