# VoiceMacroKit — 3-knob voice enhancer prototype for DaVinci Resolve (Studio, Windows)

**What this is:** a working prototype of your idea — a small tool with three
knobs (Depth / Presence / Control) that turns cheap-mic audio into a fuller,
closer, "radio / audiobook" voice — **by driving Resolve's own pre-installed
EQ, Dynamics and De-Esser instead of rebuilding them**, then saving the
result as presets.

```
Rectangle box:   [ KNOB 1: DEPTH ]  [ KNOB 2: PRESENCE ]  [ KNOB 3: CONTROL ]
```

- Knob 1 **Depth** — low-end body (+4.5 dB @140 Hz max) + mud cut (-2.5 dB @320 Hz) → *deeper, warmer voice*
- Knob 2 **Presence** — clarity (+4 dB @3.2 kHz) + air shelf (+3 dB @11 kHz) + de-esser → *closer, clearer, never sizzly*
- Knob 3 **Control** — expander + compressor + auto-makeup + limiter → *even, "radio" level*

All three knobs are 0..1, and **0 = off**: at 0/0/0 the chain is transparent
(only a fixed 70 Hz high-pass remains; verified by the test suite).

---

## 1. Which documents are the RIGHT documents (your question)

The notes you were given mix up three different SDKs. Here is the truth for
an *audio* goal:

| SDK | What it is actually for | Can it touch Fairlight audio? |
|---|---|---|
| **OpenFX (OFX)** — Dehancer-style | Compiled C++ *image* effect nodes for Color/Edit | **No — video only** |
| **Workflow Integrations** — Magic Scripts-style | Floating UI panels + automation *around* the scripting API | **No audio DSP hook; it is the UI layer** (that is what we use for the knob box) |
| **Scripting API** (Python/Lua, `Help > Documentation > Developer` in Resolve) | Projects, timelines, render queue — and exactly three audio things (below) | Presets + Voice Isolation only |

The link you asked about (`resolvedevdoc.readthedocs.io/...readme_workflow.html`)
is the **Workflow Integrations** readme — the right doc for *how a panel is
loaded and built*, the wrong doc for audio DSP. The audio-capability truth
(verified against the v21.0.4 scripting README):

- `Resolve.GetFairlightPresets()` → list of saved preset names (v20.2.2+)
- `Project.ApplyFairlightPresetToCurrentTimeline(name)` (v20.2.2+)
- `Timeline/TimelineItem Get/SetVoiceIsolationState` (v20.1+)
- **Per-parameter EQ / compressor control: does not exist in any SDK. Nobody has it.**

So "a plugin that drives Resolve's own effects from knobs" is possible only as
*this kit does it*: knobs compute the exact settings for Resolve's own tools,
you dial them in once, save as a preset — your three knobs become one click.
The `capability_probe.py` in this kit verifies all of the above **inside your
own Resolve**, so you are not trusting anyone's claims (including mine).

---

## 2. What's in the box

| File | Runs where | What it does |
|---|---|---|
| `chain_math.py` | anywhere | The whole logic: 3 knobs → complete EQ/dynamics settings (stdlib only, deterministic) |
| `voice_macro_panel.py` | **inside Resolve** | The 3-knob rectangle box (Workflow Integrations panel): knobs, Light/Medium/Strong buttons, live summary, prints the Fairlight recipe, applies Voice Isolation |
| `capability_probe.py` | **inside Resolve** | Verifies every API claim on YOUR build (version, presets, VI write+read-back) |
| `voice_macro.py` | anywhere (numpy/scipy) | Reference DSP: the same maths as an audio signal chain, offline — hear the knobs before dialling anything |
| `render_preview.py` | anywhere (numpy/scipy) | `python render_preview.py in.wav out.wav 0.6 0.6 0.4` — renders a WAV through the chain with LUFS report |
| `make_presets.py` | anywhere | Generates `presets/vm_light|medium|strong.json` + a copy-paste `RECIPE_SHEET.txt` |
| `test_voicemacro.py` | anywhere | 22-check offline suite (math identity, clamping, transparency, limiter ceiling, monotonicity) |
| `bench_e2e.py` | anywhere (ffmpeg for LUFS) | End-to-end bench on a synthetic cheap-mic clip |
| `presets/` | — | Generated settings for Light / Medium / Strong |
| `docs/VoiceMacro_Resolve_Plan.md` | — | Your full engineering plan (sources, failure-mode catalogue, validation protocol) |

---

## 3. Install & run inside Resolve (Windows, Studio 20.1+)

1. Copy the whole `VoiceMacroKit` folder to:
   `%PROGRAMDATA%\Blackmagic Design\DaVinci Resolve\Support\Workflow Integration Plugins\VoiceMacroKit`
   (If scripts do not appear, try the same path under `%APPDATA%`; the
   README in Resolve's own `Developer/Workflow Integrations` folder states
   the PROGRAMDATA path for plugins.)
2. Restart Resolve → **Workspace > Workflow Integrations** → enable/refresh →
   run `voice_macro_panel` (panel) or `capability_probe` (report).
3. The probe prints to **Workspace > Console**. Run it once; it only
   changes Voice Isolation state on audio track 1 and restores it.

Workflow with the panel (the "trick" made practical):

1. Set the knobs (or click Light/Medium/Strong), press APPLY.
2. Copy the printed recipe into Fairlight's EQ, Dynamics and De-Esser
   windows (Mixer), **once**.
3. Right-click in the EQ / Dynamics window → **Save as preset**
   (e.g. "VM Medium"). From then on, that knob combination is one click.
4. Optional: let the panel apply Voice Isolation to track 1 for you.

## 4. Recommended verification order (be independent — verify, don't trust)

1. `python test_voicemacro.py` — 22/22 must pass (pure math, no Resolve).
2. `python bench_e2e.py` — end-to-end DSP + LUFS + ceiling + presets.
3. In Resolve: run `capability_probe` — every line must say OK
   (or WARN with a reason, e.g. no timeline open).
4. `python render_preview.py your_clip.wav out.wav 0.6 0.6 0.4` — A/B
   listen, loudness-matched within 0.5 LU before judging.
5. Only then dial the recipe into Fairlight and save your presets.

Honest expectations: this chain makes a decent cheap-mic recording clearly
*nicer* — fuller, clearer, more even. It cannot turn a Zoom H1n into an
SM7B, and it cannot fix room echo, clipping or heavy noise (see the
failure-mode catalogue in `docs/VoiceMacro_Resolve_Plan.md`, section 14).

## 5. The maths (one paragraph, as requested — simple and logical)

For knobs `d, p, c` (0..1): body bell gain `4.5·d^0.8` dB @140 Hz Q0.8;
mud cut `-2.5·d` dB @320 Hz Q1.0; presence `4.0·p` dB @3.2 kHz Q1.0; air
shelf `3.0·p^1.5` dB @11 kHz; de-esser band 5.5–9 kHz with ratio `1+3p`
(grows with presence, because boosting highs makes sibilance worse);
expander threshold `noise floor + 6 dB`, ratio `1+1.5c`; compressor
threshold `-16-10c` dBFS, ratio `1+3c`, attack `12-6c` ms, release
`180-60c` ms; makeup `0.5·(-threshold)·(1-1/ratio)` (half of what the
compressor removes at threshold, given back); limiter ceiling -1 dBFS.
Exponents < 1 shape the knob feel; every constant is editable at the top
of `chain_math.py` — the one place to tune.
