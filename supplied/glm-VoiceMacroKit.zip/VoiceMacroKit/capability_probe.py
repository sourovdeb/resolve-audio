"""
capability_probe.py - verify EVERYTHING inside YOUR Resolve, yourself.

This is the "independent, without influence" tool. You run it on your own
machine, in your own Resolve (Studio, Windows), and it reports which of
this kit's assumptions hold on YOUR build. No trust in me required.

WHAT IT PROBES
  1. Python + module availability inside Resolve's scripting console.
  2. Resolve version vs. the audio functions we rely on:
       GetFairlightPresets, ApplyFairlightPresetToCurrentTimeline,
       SetVoiceIsolationState / GetVoiceIsolationState.
  3. Read-back verification: it sets Voice Isolation on audio track 1,
     reads it back, and reports whether the setter actually worked
     (the scripting docs warn some setters return True while doing
     nothing - we check, not assume).
  4. A silent live audio test: with a timeline containing audio, it
     toggles VI and measures whether ANY audio settings changed...
     no, it does not render audio (too slow + host-dependent); it
     verifies the state dict instead, which is what the API exposes.

HOW TO RUN (two ways)
  A) Console: Workspace > Console, Python, then run this file's contents.
  B) Workflow Integrations script (same folder as voice_macro_panel.py):
     it prints the report to the Console.

The probe changes ONE thing: Voice Isolation state on audio track 1
(you can turn it off again with the last command it prints). Nothing
else is touched. If no timeline/audio track exists, it skips that part.
"""

import json
import re

REPORT = []

# minimum Resolve versions (from the official scripting README, v21.0.4)
MIN_VERSIONS = {
    "GetFairlightPresets": (20, 2, 2),
    "ApplyFairlightPresetToCurrentTimeline": (20, 2, 2),
    "SetVoiceIsolationState": (20, 1, 0),
    "GetVoiceIsolationState": (20, 1, 0),
}


def log(claim, status, detail=""):
    REPORT.append({"claim": claim, "status": status, "detail": detail})
    print("[%s] %s%s" % (status, claim, (": " + detail) if detail else ""))


def _parse_version(s):
    m = re.findall(r"(\d+)", str(s))
    return tuple(int(x) for x in m[:3]) if m else (0, 0, 0)


def main(resolve, project=None):
    log("Resolve scripting API reachable", "OK",
        "resolve object received: %r" % (type(resolve).__name__,))

    ver_str = resolve.GetVersionString() if hasattr(resolve, "GetVersionString") else "?"
    log("Resolve version string", "OK" if ver_str != "?" else "WARN", ver_str)
    ver = _parse_version(ver_str)

    pm = resolve.GetProjectManager()
    project = project or (pm.GetCurrentProject() if pm else None)
    if project is None:
        log("current project open", "WARN", "none open - timeline tests skipped")
    else:
        log("current project", "OK", project.GetName())
        timeline = project.GetCurrentTimeline() if hasattr(project, "GetCurrentTimeline") else None
        if timeline is None:
            log("current timeline", "WARN", "none - audio track tests skipped")
        else:
            log("current timeline", "OK", timeline.GetName())
            n_audio = timeline.GetTrackCount("audio")
            log("audio track count", "OK" if n_audio else "WARN",
                "%d audio tracks" % n_audio)
            if n_audio:
                _probe_voice_isolation(timeline)

    _probe_fairlight_presets(resolve, project)
    _print_summary()
    return REPORT


def _probe_fairlight_presets(resolve, project):
    # GetFairlightPresets lives on the Resolve object (verified in the
    # v21.0.4 README: it is listed in the Resolve class section).
    if hasattr(resolve, "GetFairlightPresets"):
        try:
            presets = resolve.GetFairlightPresets()
            log("resolve.GetFairlightPresets()", "OK",
                "%d presets found" % len(presets or []))
            return presets
        except Exception as e:  # noqa: BLE001
            log("resolve.GetFairlightPresets()", "FAIL", str(e))
    else:
        log("resolve.GetFairlightPresets()", "FAIL",
            "not present on this build")
    # fallback probe: reported at Project level on some versions
    if project is not None and hasattr(project, "GetFairlightPresets"):
        try:
            presets = project.GetFairlightPresets()
            log("project.GetFairlightPresets()", "OK",
                "%d presets found" % len(presets or []))
        except Exception as e:  # noqa: BLE001
            log("project.GetFairlightPresets()", "FAIL", str(e))


def _probe_voice_isolation(timeline):
    # read current state first so we can restore it
    try:
        before = timeline.GetVoiceIsolationState(1)
        log("timeline.GetVoiceIsolationState(1)", "OK",
            "state before: %s" % before)
    except Exception as e:  # noqa: BLE001
        log("timeline.GetVoiceIsolationState(1)", "FAIL", str(e))
        return
    # write a known value, read back, compare -> catches setters that
    # "return True but do nothing"
    probe_state = {"isEnabled": True, "amount": 55}
    try:
        ret = timeline.SetVoiceIsolationState(1, probe_state)
        after = timeline.GetVoiceIsolationState(1)
        if (after or {}).get("amount") == 55:
            log("SetVoiceIsolationState write+readback", "OK",
                "set %r -> read %r (setter really works)" % (probe_state, after))
        else:
            log("SetVoiceIsolationState write+readback", "FAIL",
                "set %r -> read %r (setter may lie; do not rely on it)" % (probe_state, after))
    except Exception as e:  # noqa: BLE001
        log("SetVoiceIsolationState write+readback", "FAIL", str(e))
    # restore original state
    try:
        timeline.SetVoiceIsolationState(1, before)
        print("(original Voice Isolation state restored on track 1)")
    except Exception as e:  # noqa: BLE001
        print("(could not restore original VI state: %s)" % e)


def _print_summary():
    print()
    print("=" * 62)
    ok = sum(1 for r in REPORT if r["status"] == "OK")
    fail = sum(1 for r in REPORT if r["status"] == "FAIL")
    warn = sum(1 for r in REPORT if r["status"] == "WARN")
    print("Probe summary: %d OK, %d WARN, %d FAIL" % (ok, warn, fail))
    print("=" * 62)
    if fail == 0 and warn == 0:
        print("All capability assumptions verified on this build.")
    elif fail == 0:
        print("Core capabilities OK; warnings above are environment "
              "gaps (open a project/timeline to clear them).")
    else:
        print("Some capabilities are MISSING on this build - read the "
              "FAIL lines above; the kit's README maps them to workarounds.")
    print()
    print(json.dumps(REPORT, indent=2))
    return REPORT


def run(resolve=None, project=None):
    if resolve is None:
        print(__doc__)
        return None
    return main(resolve, project)


if __name__ == "__main__":
    import sys
    if "resolve" in globals():
        main(globals()["resolve"], globals().get("project"))
    else:
        print(__doc__)
        print("(inside Resolve: run via Workspace > Console, or as a "
              "Workflow Integration script)")
