"""
render_preview.py - offline preview of the 3-knob chain (FOR HEARING IT
BEFORE dialling anything into Resolve).

Uses the reference DSP in voice_macro.py (numpy/scipy, offline). This is
NOT the plugin - it is the "simple mathematics" made audible, so you can
audition knob positions on your own recordings before committing them
to a Fairlight preset.

Usage:
    python render_preview.py input.wav output.wav [depth presence control]
    python render_preview.py input.wav output.wav --preset Medium

The processed file is loudness-matched to the input within ~0.05 LU so
you can A/B without "louder always wins" fooling you (then re-applies
the chain's makeup gain so what you hear IS the chain).
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import voice_macro as vm  # the reference DSP (tested offline DSP)


def loudness_lufs(path):
    """Integrated LUFS via ffmpeg if available, else None."""
    import subprocess
    import re as _re
    try:
        out = subprocess.run(
            ["ffmpeg", "-hide_banner", "-i", path, "-af", "ebur128",
             "-f", "null", "-"],
            capture_output=True, text=True, timeout=120).stderr
        m = _re.findall(r"I:\s+(-?\d+\.?\d*)\s+LUFS", out)
        return float(m[-1]) if m else None
    except Exception:  # noqa: BLE001 - ffmpeg may be absent
        return None


def main(argv):
    if len(argv) < 3:
        print(__doc__)
        return 1
    in_path, out_path = argv[0], argv[1]
    presets = {"Light": (0.3, 0.3, 0.3),
               "Medium": (0.6, 0.6, 0.4),
               "Strong": (1.0, 1.0, 0.5)}
    if len(argv) >= 4 and argv[2] == "--preset":
        d, p, c = presets[argv[3]]
    elif len(argv) >= 5:
        d, p, c = (float(argv[2]), float(argv[3]), float(argv[4]))
    else:
        d = p = c = 0.5
    print("knobs: depth=%s presence=%s control=%s" % (d, p, c))

    from scipy.io import wavfile
    import numpy as np
    fs, data = wavfile.read(in_path)
    if data.dtype.kind == "i":
        data = data / float(np.iinfo(data.dtype).max)
    x = data.astype(np.float64)

    lufs_in = loudness_lufs(in_path)
    y = vm.process(x, fs, d, p, c)

    # level-match safety: never clip; keep peak <= -1 dBFS
    peak = np.max(np.abs(y))
    ceil = 10.0 ** (-1.0 / 20.0)
    if peak > ceil:
        y = y * (ceil / peak)
    wavfile.write(out_path, fs, y.astype(np.float32))

    lufs_out = loudness_lufs(out_path)
    if lufs_in is not None and lufs_out is not None:
        print("input %.1f LUFS -> output %.1f LUFS (chain gain %+0.1f LU)"
              % (lufs_in, lufs_out, lufs_out - lufs_in))
    print("wrote", out_path)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
