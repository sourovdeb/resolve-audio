"""
voice_macro_panel.py - the "rectangle box with 3 knobs", as a Workflow
Integration script for DaVinci Resolve (Studio, Windows).

WHAT THIS IS
  A floating panel inside Resolve (Workspace > Workflow Integrations)
  with three knobs:
      Knob 1  DEPTH    - low-end body + mud cut   ("deeper voice")
      Knob 2  PRESENCE - clarity, air, de-esser   ("closer voice")
      Knob 3  CONTROL  - expander + comp + makeup ("radio-even voice")
  The panel computes the full settings for Resolve's own EQ / Dynamics /
  De-Esser (chain_math.fairlight_recipe) and shows them; it can also apply
  the scriptable parts to the current timeline's first audio track:
  Voice Isolation on/off + amount (the only audio settings the scripting
  API exposes, v20.1+).

WHAT IT CANNOT DO (verified against the v21.0.4 scripting API)
  It cannot turn your knob positions into Fairlight EQ/dynamics parameter
  changes live - Resolve exposes no such interface. Nobody has that; it
  is not a missing feature of this code. The intended workflow:
  the panel COMPUTES the settings, YOU dial them into Resolve's EQ /
  Dynamics windows once, save as a preset - the knobs are then one click.

INSTALL (Windows)
  Copy VoiceMacroKit/ into:
    %PROGRAMDATA%\\Blackmagic Design\\DaVinci Resolve\\
        Support\\Workflow Integration Plugins\\VoiceMacroKit
  Restart Resolve; enable scripts under Workspace > Workflow Integrations.
  (Folder may also be under %APPDATA% depending on version - README
  has the troubleshooting table.)

REQUIREMENTS: Resolve Studio 20.1+ on Windows. Uses only the Python
standard library (UIManager runs inside Resolve's own Python).
"""

import json

PANEL_ID = "VoiceMacroPanel"


# ---------------------------------------------------------------------------
# pure-Python part - unit-tested outside Resolve, no Resolve imports
# ---------------------------------------------------------------------------
def _clamp01(v):
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else float(v))


def _default_presets():
    return {"Light": (0.3, 0.3, 0.3),
            "Medium": (0.6, 0.6, 0.4),
            "Strong": (1.0, 1.0, 0.5)}


class PanelLogic:
    """Everything the panel does, minus the UI. Kept separate so the
    logic can be tested on any machine without Resolve installed."""

    def __init__(self, presets=None):
        self.presets = presets or _default_presets()
        self.depth = 0.5
        self.presence = 0.5
        self.control = 0.5
        self.preset_name = "Medium"

    def set_knobs(self, depth, presence, control):
        self.depth = _clamp01(depth)
        self.presence = _clamp01(presence)
        self.control = _clamp01(control)
        return self.knobs()

    def knobs(self):
        return (self.depth, self.presence, self.control)

    def apply_named(self, name):
        if name not in self.presets:
            return None
        self.depth, self.presence, self.control = self.presets[name]
        self.preset_name = name
        return self.knobs()

    def summary_line(self):
        """One-line 'what you should hear' for the status label."""
        d, p, c = self.knobs()
        parts = []
        parts.append("body +%.1f dB @140 Hz" % (4.5 * d ** 0.8))
        parts.append("presence +%.1f dB @3.2 kHz" % (4.0 * p))
        parts.append("comp %.1f:1" % (1.0 + 3.0 * c))
        return "   |   ".join(parts)

    def recipe(self, chain_math, fs=48000, source_floor_db=-50.0):
        return chain_math.fairlight_recipe(
            self.depth, self.presence, self.control,
            fs=fs, source_floor_db=source_floor_db)

    def voice_isolation_setting(self):
        """The only audio setting the scripting API can set live, mapped
        from the knobs (per Resolve docs, amount is 0..100 int)."""
        enabled = self.presence > 0.05 or self.control > 0.05
        amount = int(round(50.0 * (self.presence + self.control) / 2.0))
        return {"isEnabled": enabled, "amount": max(0, min(100, amount))}

    def recipe_text(self, chain_math, source_floor_db=-50.0):
        """Multi-line settings text for the panel's readout (and console)."""
        r = self.recipe(chain_math, source_floor_db=source_floor_db)
        eq, deess, dyn = r["eq"], r["deesser"], r["dynamics"]
        comp, exp = dyn["compressor"], dyn["expander"]
        L = []
        L.append("FAIRLIGHT EQ (Mixer > EQ):")
        L.append("  HP %g Hz   body %g Hz q%g %+g dB   mud %g Hz q%g %+g dB"
                 % (eq["band1_highpass_hz"],
                    eq["band2_body"]["freq_hz"], eq["band2_body"]["q"],
                    eq["band2_body"]["gain_db"],
                    eq["band3_mud"]["freq_hz"], eq["band3_mud"]["q"],
                    eq["band3_mud"]["gain_db"]))
        L.append("  presence %g Hz q%g %+g dB   air %g Hz shelf %+g dB"
                 % (eq["band4_presence"]["freq_hz"], eq["band4_presence"]["q"],
                    eq["band4_presence"]["gain_db"],
                    eq["band5_airs"]["freq_hz"], eq["band5_airs"]["gain_db"]))
        L.append("DE-ESSER (FX): %g Hz, %s, expect ~%g dB reduction"
                 % (deess["freq_hz"], deess["mode"],
                    deess["expected_reduction_db"]))
        L.append("DYNAMICS (Mixer > Dynamics):")
        L.append("  expander  thr %g dB, %g:1, atk %g ms, rel %g ms"
                 % (exp["threshold_db"], exp["ratio"],
                    exp["attack_ms"], exp["release_ms"]))
        L.append("  comp      thr %g dB, %g:1, atk %g ms, rel %g ms, makeup %+g dB"
                 % (comp["threshold_db"], comp["ratio"],
                    comp["attack_ms"], comp["release_ms"], comp["makeup_db"]))
        L.append("  limiter   ceiling %g dBFS" % dyn["limiter"]["ceiling_dbfs"])
        return "\n".join(L)


# ---------------------------------------------------------------------------
# Resolve-side: the UIManager window (runs only inside Resolve)
# ---------------------------------------------------------------------------
def _knob(ui, id_, title, tooltip):
    return ui.VGroup([
        ui.Label({"Text": title, "ToolTip": tooltip}),
        ui.Slider({"ID": id_, "Minimum": 0, "Maximum": 100,
                   "Value": 50, "Orientation": "Vertical",
                   "ToolTip": tooltip}),
    ])


def run_panel(resolve=None, project=None, fusion=None):
    """Build and show the panel. `resolve`/`project`/`fusion` are
    auto-injected when run as a Workflow Integration script."""
    import os
    import sys
    # make the sibling chain_math.py importable no matter what the
    # current working directory is when Resolve launches this script
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import chain_math

    ui = fusion.UIManager()
    dispatcher = bmd.UIDispatcher(ui)  # bmd is auto-injected by Resolve
    logic = PanelLogic()

    cfg = {"ID": PANEL_ID, "WindowTitle": "Voice Macro - 3 knobs"}
    win = dispatcher.AddWindow(cfg, [
        ui.Label({"ID": "lblTitle", "Text": "VOICE MACRO",
                  "Font": {"Family": "Arial", "PixelSize": 18},
                  "ToolTip": "3-knob voice chain calculator + applier"}),
        ui.Label({"ID": "lblSub", "Text":
                  "computes settings for Resolve's own EQ / Dynamics"}),
        ui.HGroup([
            _knob(ui, "knob1", "K1 Depth", "Low-end body & mud cut"),
            _knob(ui, "knob2", "K2 Presence", "Clarity, air, de-esser"),
            _knob(ui, "knob3", "K3 Control", "Expander, comp, makeup"),
        ]),
        ui.HGroup([
            ui.Button({"ID": "btnLight", "Text": "Light"}),
            ui.Button({"ID": "btnMedium", "Text": "Medium"}),
            ui.Button({"ID": "btnStrong", "Text": "Strong"}),
        ]),
        ui.Label({"ID": "lblSummary", "Text": "..."}),
        ui.CheckBox({"ID": "chkApplyVI", "Text":
                     "Also apply Voice Isolation to selected track"}),
        ui.Button({"ID": "btnApply", "Text": "APPLY (print EQ/Dyn recipe)"}),
        ui.Button({"ID": "btnClose", "Text": "Close"}),
    ])

    def refresh():
        d, p, c = logic.knobs()
        for kid, val in zip(("knob1", "knob2", "knob3"), (d, p, c)):
            win.Find(kid).Value = int(round(val * 100))
        win.Find("lblSummary").Text = logic.summary_line()

    def on_any_knob(_ev):
        logic.set_knobs(win.Find("knob1").Value / 100.0,
                       win.Find("knob2").Value / 100.0,
                       win.Find("knob3").Value / 100.0)
        refresh()

    for kid in ("knob1", "knob2", "knob3"):
        win.On[kid].ValueChanged = on_any_knob

    def preset_button(name):
        def handler(_ev):
            logic.apply_named(name)
            refresh()
        return handler

    win.On.btnLight.Clicked = preset_button("Light")
    win.On.btnMedium.Clicked = preset_button("Medium")
    win.On.btnStrong.Clicked = preset_button("Strong")

    def on_apply(_ev):
        vi_result = None
        if win.Find("chkApplyVI").Checked:
            vi_result = apply_voice_isolation(resolve, project, logic)
        # The recipe goes to the console (Workspace > Console) because it
        # is longer than a label can show nicely.
        print(logic.recipe_text(chain_math))
        if vi_result is not None:
            print("Voice Isolation applied to audio track 1: %r" % vi_result)

    win.On.btnApply.Clicked = on_apply
    win.On[PANEL_ID].Close = lambda _ev: dispatcher.ExitLoop()
    win.On.btnClose.Clicked = lambda _ev: dispatcher.ExitLoop()

    refresh()
    win.Show()
    dispatcher.RunLoop()
    return logic


def apply_voice_isolation(resolve, project, logic):
    """Apply Voice Isolation to the FIRST audio track of the current
    timeline (whole-timeline preset applies are destructive; VI is
    track-scoped, so it is the safe one to script)."""
    try:
        timeline = project.GetCurrentTimeline()
        if timeline is None:
            return "no current timeline"
        n = timeline.GetTrackCount("audio")
        if not n:
            return "no audio tracks"
        state = logic.voice_isolation_setting()
        ok = timeline.SetVoiceIsolationState(1, state)
        return ok if ok is not None else True
    except Exception as e:  # noqa: BLE001 - reported to the user, not raised
        return "error: %s" % e


# ---------------------------------------------------------------------------
# Entry point: works both as a Workflow Integration script (Resolve
# injects `resolve`, `project`, `fusion`, `bmd`) and from a console for
# headless math checks:  python voice_macro_panel.py 0.4 0.6 0.3
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 4:
        d, p, c = (float(sys.argv[i]) for i in (1, 2, 3))
        logic = PanelLogic()
        logic.set_knobs(d, p, c)
        import chain_math
        print(logic.recipe_text(chain_math))
        print()
        print("Voice Isolation setting:", json.dumps(
            logic.voice_isolation_setting()))
    else:
        # no args and no injected Resolve globals -> print usage
        if "fusion" in globals():
            run_panel(resolve=globals().get("resolve"),
                      project=globals().get("project"),
                      fusion=globals().get("fusion"))
        else:
            print(__doc__)
            print("usage: python voice_macro_panel.py <depth> <presence> "
                  "<control>   (each 0..1) prints the Fairlight recipe")
