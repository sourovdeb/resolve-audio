"""
chain_math.py - the entire "logic" of the 3-knob Voice Macro.

Everything here is simple, deterministic arithmetic: knob positions in,
a complete description of an audio-processing chain out. No magic, no
guesswork - the same input always yields the same numbers, on any machine.

    depth     (knob 1)  -> low-end body + mud cut          ("deeper voice")
    presence  (knob 2)  -> clarity, air, de-esser          ("closer voice")
    control   (knob 3)  -> expander + compressor + makeup  ("radio-even voice")

Two outputs are derived from the SAME knob values:

  1) fairlight_recipe()  - what to dial into Resolve's own built-in
     EQ / Dynamics / De-Esser / Noise Reduction (the "use Resolve's own
     effects as our tools" trick - we drive them, not rebuild them).
  2) The knob -> dB map used by the offline preview DSP.

Works with Python 3.8+ stdlib only (no numpy needed here).
"""

import math


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _clip01(v):
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else float(v))


def _round(x, nd=1):
    """Round to `nd` decimals and drop -0.0 / float noise for clean output."""
    r = round(float(x), nd)
    return 0.0 if r == 0 else r


# ---------------------------------------------------------------------------
# 1) KNOB -> PARAMETER MAP (the "simple mathematics" of this plugin)
# ---------------------------------------------------------------------------
def map_knobs(depth, presence, control, fs=48000):
    """All three knobs are 0..1. 0 = that stage is OFF (transparent).

    Every constant below was chosen from standard voice-chain practice:
      - 70 Hz HPF      : removes rumble, keeps voice fundamentals
      - 140 Hz body    : proximity warmth of a large-diaphragm/broadcast mic
      - 320 Hz mud cut : keeps the body boost from turning boomy
      - 3.2 kHz pres   : intelligibility band (voice consonants live here)
      - 11 kHz air     : gentle brilliance shelf, not harsh
    Exponents < 1 (d**0.8, p**1.5) shape the knob's feel: depth/presence
    act early in their travel; presence's de-esser gets stronger as
    presence rises (boosting highs makes sibilance worse, so the chain
    compensates for its own side effect).
    """
    d, p, c = _clip01(depth), _clip01(presence), _clip01(control)
    return {
        # -- fixed -------------------------------------------------------
        "hpf_hz": 70.0,
        # -- Depth -------------------------------------------------------
        "body_hz": 140.0, "body_q": 0.8, "body_db": 4.5 * d ** 0.8,
        "mud_hz": 320.0, "mud_q": 1.0, "mud_db": -2.5 * d,
        # -- Presence ----------------------------------------------------
        "pres_hz": 3200.0, "pres_q": 1.0, "pres_db": 4.0 * p,
        "air_hz": min(11000.0, 0.45 * fs), "air_db": 3.0 * p ** 1.5,
        "ess_lo": 5500.0, "ess_hi": min(9000.0, 0.45 * fs),
        "ess_ratio": 1.0 + 3.0 * p, "ess_thr_rel_db": -9.0 - 3.0 * p,
        "ess_max_red_db": 9.0,
        # -- Control -----------------------------------------------------
        "exp_ratio": 1.0 + 1.5 * c, "exp_above_floor_db": 6.0,
        "exp_max_red_db": 12.0,
        "comp_thr_db": -16.0 - 10.0 * c, "comp_ratio": 1.0 + 3.0 * c,
        "comp_knee_db": 6.0,
        "comp_att_ms": 12.0 - 6.0 * c, "comp_rel_ms": 180.0 - 60.0 * c,
        # half of the gain the compressor removes at threshold is given
        # back as makeup (rule of thumb; trim by ear afterwards)
        "makeup_db": 0.5 * (16.0 + 10.0 * c) * (1.0 - 1.0 / (1.0 + 3.0 * c)),
        "limit_ceiling_db": -1.0,
    }


# ---------------------------------------------------------------------------
# 2) KNOBS -> FAIRLIGHT RECIPE (what to dial into Resolve's own effects)
# ---------------------------------------------------------------------------
def fairlight_recipe(depth, presence, control, fs=48000, source_floor_db=-50.0):
    """A step-by-step recipe for Resolve's PRE-INSTALLED audio effects.

    This is the core of the "take advantage of already established
    equalizer and dynamics" technique: instead of building new DSP, the
    knobs compute the exact settings for Fairlight's own EQ, Dynamics,
    De-Esser, Noise Reduction and Voice Isolation. You dial them once,
    save each combination as a Fairlight preset (right-click in the Mixer
    / Inspector), and from then on your three knobs are one click.

    `source_floor_db` = measured noise floor of your source (dBFS).
    Real recordings sit between -60 (quiet room) and -35 (noisy room);
    the expander threshold is derived from it.
    """
    P = map_knobs(depth, presence, control, fs)
    exp_thr = source_floor_db + P["exp_above_floor_db"]

    recipe = {
        "_meta": {
            "knobs": {"depth": _round(depth, 2), "presence": _round(presence, 2),
                      "control": _round(control, 2)},
            "source_floor_db": source_floor_db,
            "sample_rate_hz": fs,
            "note": "Settings for Resolve's built-in EQ / Dynamics / "
                    "De-Esser / Noise Reduction. Save as a Fairlight "
                    "preset after dialling them in once.",
        },
        "eq": {  # Fairlight track EQ (6 bands) - open EQ in the Mixer
            "band1_highpass_hz": _round(P["hpf_hz"], 0),
            "band2_body": {"freq_hz": P["body_hz"], "q": P["body_q"],
                           "gain_db": _round(P["body_db"], 1)},
            "band3_mud": {"freq_hz": P["mud_hz"], "q": P["mud_q"],
                         "gain_db": _round(P["mud_db"], 1)},
            "band4_presence": {"freq_hz": P["pres_hz"], "q": P["pres_q"],
                               "gain_db": _round(P["pres_db"], 1)},
            "band5_airs": {"freq_hz": _round(P["air_hz"], 0), "type": "high shelf",
                           "gain_db": _round(P["air_db"], 1)},
            "band6_airs2": {"freq_hz": _round(P["air_hz"], 0), "type": "high shelf",
                           "gain_db": _round(P["air_db"], 1)},
        },
        "deesser": {  # Fairlight De-Esser FX (Effects tab of the Mixer)
            "freq_hz": _round(math.sqrt(P["ess_lo"] * P["ess_hi"]), 0),
            "threshold_db": -24.0 + 6.0 * P["ess_ratio"] / 4.0,  # tuning guide
            "mode": "wide band 5.5-9 kHz" if p_active(P) else "bypass",
            "expected_reduction_db": _round(1.0 + 2.0 * P["ess_ratio"] / 4.0, 1),
        },
        "dynamics": {  # Fairlight Dynamics (expander + comp + limiter)
            "expander": {
                "threshold_db": _round(exp_thr, 1),
                "ratio": _round(P["exp_ratio"], 2),
                "attack_ms": 3.0, "release_ms": 120.0,
                "max_reduction_db": P["exp_max_red_db"],
            },
            "compressor": {
                "threshold_db": _round(P["comp_thr_db"], 1),
                "ratio": _round(P["comp_ratio"], 2),
                "attack_ms": _round(P["comp_att_ms"], 1),
                "release_ms": _round(P["comp_rel_ms"], 0),
                "makeup_db": _round(P["makeup_db"], 1),
            },
            "limiter": {"ceiling_dbfs": -1.0},
        },
        "voice_isolation": {  # scriptable directly (v20.1+) - optional
            "enable": (control > 0.05 or presence > 0.05),
            "amount_pct": _round(50.0 * (presence + control) / 2.0, 0),
        },
        "noise_reduction": {  # optional, noisy sources only
            "enable": control > 0.4,
            "amount_pct": _round(40.0 * control, 0),
        },
    }
    return recipe


def p_active(P):
    return P["pres_db"] > 0.05


# ---------------------------------------------------------------------------
# 3) NAMED SETTINGS (what the panel's preset buttons load)
# ---------------------------------------------------------------------------
def named_settings():
    """Light / Medium / Strong - the three preset points of the knob space."""
    return {
        "Light": (0.3, 0.3, 0.3),
        "Medium": (0.6, 0.6, 0.4),
        "Strong": (1.0, 1.0, 0.5),
    }


def interpolate(depth, presence, control, target, t):
    """Move current knobs toward `target` (a 3-tuple) by fraction t (0..1).
    Used by the panel to animate knobs smoothly toward a named preset."""
    return tuple(a + (b - a) * t
                 for a, b in zip((depth, presence, control), target))


# ---------------------------------------------------------------------------
# 4) PREVIEW-ONLY: net static EQ response (for docs/plots; needs numpy)
# ---------------------------------------------------------------------------
def eq_response_db(depth, presence, control, fs=48000, freqs=None):
    """Magnitude in dB of the static EQ (HPF + bells + shelf) at `freqs`.
    Requires numpy + scipy (offline tooling only; Resolve panel never
    imports this)."""
    import numpy as np
    from scipy import signal
    if freqs is None:
        freqs = [60, 100, 140, 200, 320, 500, 1000, 3200, 6000, 10000, 16000]
    P = map_knobs(depth, presence, control, fs)
    sos = build_eq_sos(P, fs)
    _, h = signal.sosfreqz(sos, worN=np.asarray(freqs, dtype=float), fs=fs)
    return freqs, 20 * np.log10(np.abs(h))


def build_eq_sos(P, fs):
    """Same section list as the offline DSP, stdlib-only for inspection."""
    from scipy import signal
    sections = [signal.butter(2, P["hpf_hz"], "highpass", fs=fs, output="sos")]
    sections.append(peaking(fs, P["body_hz"], P["body_q"], P["body_db"]))
    sections.append(peaking(fs, P["mud_hz"], P["mud_q"], P["mud_db"]))
    sections.append(peaking(fs, P["pres_hz"], P["pres_q"], P["pres_db"]))
    sections.append(high_shelf(fs, P["air_hz"], P["air_db"]))
    return np_vstack(sections)


def peaking(fs, f0, q, gain_db):
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * f0 / fs
    al = math.sin(w0) / (2 * q)
    c = math.cos(w0)
    b0, b1, b2 = 1 + al * A, -2 * c, 1 - al * A
    a0, a1, a2 = 1 + al / A, -2 * c, 1 - al / A
    return [[b0 / a0, b1 / a0, b2 / a0, 1.0, a1 / a0, a2 / a0]]


def high_shelf(fs, f0, gain_db, S=1.0):
    A = 10 ** (gain_db / 40.0)
    w0 = 2 * math.pi * f0 / fs
    c, s = math.cos(w0), math.sin(w0)
    al = s / 2 * math.sqrt((A + 1 / A) * (1 / S - 1) + 2)
    r = 2 * math.sqrt(A) * al
    b0 = A * ((A + 1) + (A - 1) * c + r)
    b1 = -2 * A * ((A - 1) + (A + 1) * c)
    b2 = A * ((A + 1) + (A - 1) * c - r)
    a0 = (A + 1) - (A - 1) * c + r
    a1 = 2 * ((A - 1) - (A + 1) * c)
    a2 = (A + 1) - (A - 1) * c - r
    return [[b0 / a0, b1 / a0, b2 / a0, 1.0, a1 / a0, a2 / a0]]


def np_vstack(sections):
    import numpy as np
    return np.vstack(sections)


# ---------------------------------------------------------------------------
# 5) CLI: print the recipe for any knob combination
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys, json
    if len(sys.argv) >= 4:
        d, p, c = (float(sys.argv[i]) for i in (1, 2, 3))
    else:
        d = p = c = 0.5
        print("no knobs given, using 0.5/0.5/0.5")
    print(json.dumps(fairlight_recipe(d, p, c), indent=2))
