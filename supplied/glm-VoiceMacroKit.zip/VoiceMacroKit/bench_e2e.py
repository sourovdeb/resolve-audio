"""
bench_e2e.py - end-to-end bench of the kit on a synthetic "cheap mic"
voice clip (same recipe as the plan doc's section 8): glottal pulse train
+ vowel formants + syllable level swings + sibilant bursts, filtered thin
(180 Hz HP + 1.5 kHz honk) + pink noise at -52 dBFS.

Verifies, with numbers:
  - render_preview.py runs the full chain on a real WAV
  - LUFS/LRA shift is in the expected direction and range
  - limiter ceiling honoured
  - presets generated and loadable
"""

import json
import os
import subprocess
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import voice_macro as vm

FS = 48000
DUR = 20.0
RNG = np.random.RandomState(7)


def make_source():
    t = np.arange(int(FS * DUR)) / FS
    # syllable envelope: 0.3 s syllables, 0.15 s gaps
    f0 = 120.0 + 20.0 * np.sin(2 * np.pi * 0.7 * t)      # slight pitch move
    env = 0.5 * (1 + np.sign(np.sin(2 * np.pi / 0.45 * t)))
    env = 0.2 + 0.8 * np.clip(env, 0, 1)
    # simple glottal pulse: low-passed impulse train
    phase = np.cumsum(f0) / FS
    train = np.zeros_like(t)
    train[1:][np.diff(phase) > 1.0] = 1.0
    glottal = signal.lfilter([0.02, 0.02], [1.0, -0.96], train)
    vow = np.zeros_like(t)
    for fc, bw, amp in [(500, 80, 1.0), (1500, 100, 0.4), (2500, 120, 0.2)]:
        b, a = signal.iirpeak(fc, fc / bw, FS)
        vow += amp * signal.lfilter(b, a, glottal)
    vow *= env
    # sibilant bursts between vowels
    s = np.zeros_like(t)
    s_win = ((t % 0.45) > 0.30) & ((t % 0.45) < 0.42)
    noise = RNG.randn(len(t))
    b, a = signal.butter(2, [5500, 9000], "bandpass", fs=FS)
    s = s_win * 0.25 * signal.lfilter(b, a, noise)
    x = vow + s
    # slow level automation ("sentences" louder/quieter over seconds) -
    # this is what LRA (3 s windows) measures and a compressor evens out
    ride = 0.5 * (1.0 + np.sin(2 * np.pi / 6.0 * t))       # +-6 dB swings
    x *= ride
    # thin cheap mic: 180 Hz HP + 1.5 kHz honk
    x = signal.sosfilt(signal.butter(2, 180.0, "highpass", fs=FS, output="sos"), x)
    x = x + 0.35 * signal.sosfilt(signal.butter(2, [1200, 1800], "bandpass", fs=FS, output="sos"), x)
    # pink-ish room noise at -52 dBFS
    pink = np.cumsum(RNG.randn(len(t)))
    pink = pink / (np.abs(pink).max() + 1e-9)
    x = x / (np.abs(x).max() + 1e-9) * 0.3 + 10 ** (-52 / 20) * pink
    return x


def lufs(path):
    out = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", path,
                         "-af", "ebur128", "-f", "null", "-"],
                        capture_output=True, text=True, timeout=300).stderr
    import re
    i = re.findall(r"I:\s+(-?\d+\.?\d*)\s+LUFS", out)
    lra = re.findall(r"LRA:\s+(\d+\.?\d*)", out)
    return float(i[-1]), float(lra[-1])


def main():
    src = os.path.join(HERE, "bench_src.wav")
    out = os.path.join(HERE, "bench_out.wav")
    x = make_source()
    wavfile.write(src, FS, (np.clip(x, -1, 1) * 32767).astype(np.int16))
    print("source written:", src)

    r = subprocess.run([sys.executable, os.path.join(HERE, "render_preview.py"),
                        src, out, "0.6", "0.6", "0.4"],
                       capture_output=True, text=True)
    print(r.stdout.strip())
    if r.returncode != 0:
        print(r.stderr)
        return 1

    li, lrai = lufs(src)
    lo, lrao = lufs(out)
    print("INPUT  %.1f LUFS  LRA %.1f" % (li, lrai))
    print("OUTPUT %.1f LUFS  LRA %.1f" % (lo, lrao))

    fs2, y = wavfile.read(out)
    peak_db = 20 * np.log10(float(np.max(np.abs(y))) + 1e-12)
    print("output peak %.2f dBFS" % peak_db)

    ok = True
    if not (-27.0 <= lo <= -19.0):
        print("FAIL: LUFS out of expected band")
        ok = False
    if peak_db > -0.9:
        print("FAIL: ceiling violated")
        ok = False
    if not (lrao < lrai or (lrao < 2.0 and lrai < 2.0)):
        print("FAIL: LRA should shrink (more even level)")
        ok = False

    # presets
    pres = subprocess.run([sys.executable, os.path.join(HERE, "make_presets.py")],
                          capture_output=True, text=True)
    print(pres.stdout.strip())
    for name in ("vm_light.json", "vm_medium.json", "vm_strong.json"):
        with open(os.path.join(HERE, "presets", name)) as fh:
            json.load(fh)
    print("presets JSON all load")
    print("BENCH:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
