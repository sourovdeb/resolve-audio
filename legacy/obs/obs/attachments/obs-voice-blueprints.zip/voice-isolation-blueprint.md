# OBS Voice Isolation

**App 2 of 2. Blueprint only. Nothing is built yet.**
**Date:** 2026-11-25
**Companion:** `voice-match-blueprint.json`. On the microphone, this filter sits **above** Voice Match.

The notes in `opinions/voice-isolation-blueprint.md` are not this spec. Where they disagree, this file wins.

## What the toggle does

One control. The filter's eye icon, and one hotkey that flips that eye.

On: speech stays, steady noise is turned down.
Off: the microphone is untouched.

That is the whole product for the first version.

## What those words do not mean

"Keep the voice and remove the rest" hides three jobs. Only the first one is this toggle.

| Job | What it removes | What it leaves | In v1 |
|---|---|---|---|
| Noise removal | Fan, hum, hiss, a lot of room hiss | Other people, television dialogue, music | Yes. This is the toggle. |
| Speech cleanup | A moderate amount of music as well | Other people talking | No. Only if the tests below fail. |
| My voice only | Other people when you are not talking | Nobody, including you, when two people talk at once | No. A different project, after this one works. |

RNNoise, which OBS already ships, is a noise remover. It is not a "delete every voice except mine" switch. Building a second copy of it inside a new plugin does not make the first version better.

## Why it is a script first

Checked against the OBS scripting page (the page says OBS Studio 33.0.3):

- A script can load, draw properties, tick, and register a hotkey with `obs_hotkey_register_frontend`.
- No script callback receives microphone samples.
- The Lua script-source example on that page is a video source. It does not show an audio filter.

So the first version does not process audio itself. It turns OBS's own Noise Suppression filter on and off. That filter is already the highest-quality noise remover OBS ships without an extra download.

A native plugin is the second version, and only if the listening tests say the built-in filter is not enough. See "When a plugin is worth writing".

## What was checked

| Fact | Status |
|---|---|
| Filter id `noise_suppress_filter` | In the current obs-filters source. Version 2 is the live one. Version 1 is marked obsolete. |
| Setting key `method` | Same file. String `rnnoise` is RNNoise. String `speex` is Speex. |
| Setting key `suppress_level` | Speex only. RNNoise has no strength slider in OBS. |
| RNNoise is the default on a current OBS, and it needs no download | OBS's own noise-suppression guide, and the filter source. It runs on Windows, macOS and Linux. |
| Speex has a Suppression Level. The 2022 OBS article says the slider runs from -60 dB to 0 dB and defaults to -30 dB. | That article is old. Use -30 only as the fallback, and confirm the key on your OBS before shipping the script. |
| NVIDIA noise removal needs the NVIDIA Audio Effects SDK and an NVIDIA RTX GPU. NVIDIA's list, as reported by current guides, starts at GeForce RTX 2060. | An RTX 3050 is a later card, so it should qualify, but the script does not depend on it. |
| NVIDIA may be a method inside Noise Suppression, or a separate filter, depending on the OBS version. A 2024 change proposed moving it out. The master source still contains NVIDIA ifdef blocks. | Not settled for your installed OBS. The script must not guess the NVIDIA setting string. |

## The script

**File:** `obs/script/isolate_voice.lua`

Lua, not Python. Lua is inside OBS. Python asks for a separate install, and this script does no maths, so Python buys nothing.

**Behaviour:**

1. A dropdown lists audio sources.
2. A checkbox, "Isolation on", and a hotkey, "Toggle voice isolation".
3. On the chosen source, if a filter named `Voice Isolation` is missing, create `noise_suppress_filter` with `method` set to `rnnoise`.
4. The checkbox and the hotkey call `obs_source_set_enabled` on that filter. They do not create a second one.
5. If `rnnoise` is not in the method list, use `speex` at `suppress_level` -30 and write one line to the OBS log: `Voice Isolation is using Speex because RNNoise is not available.`
6. If the source already has a noise-suppression filter, do not stack another. Enable or disable the one that is there, and log that.

**No strength slider.** RNNoise does not have one. Speex's level stays at the single fallback value.

**First lines of the script, before any of the above, check the bindings.** The C functions `obs_source_filter_add`, `obs_source_get_filter_by_name` and `obs_source_set_enabled` exist. The scripting page does not list them. If Lua does not export them, the script cannot create the filter. In that case it tells you to add Noise Suppression once by hand, method RNNoise, and it only flips the eye after that.

**Hotkey does nothing:** OBS Settings, Hotkeys, rebind "Toggle voice isolation".

## How you use it with Voice Match

Filter order, top to bottom:

1. Voice Isolation
2. Voice Match
3. No Gain, no Compressor, no Limiter of OBS's own

Voice Match measures the voice and copies that measurement. A dirty measurement produces a dirty correction. Its blueprint already says: if speech sits less than 15 dB above the quiet frames, cut the tone correction in half.

## Tests, before anyone talks about a plugin

Record the same ten minutes twice, once with the eye off and once with it on. Keep both files.

| # | What you record | What "good" means |
|---|---|---|
| 1 | The quiet room, 30 seconds, no talking | The noise is obviously quieter. A number is welcome: the level should drop by about 20 dB or more. If it does not, say so. Do not call it a pass. |
| 2 | Ordinary speech, quiet room | The voice is not underwater, and word endings are not chopped. One clipped word in ten sentences is the limit. |
| 3 | Speech with the fan or the air conditioner | The fan drops. The voice still passes test 2. |
| 4 | Speech while typing | Keys should be hard to hear at a normal volume. This one often fails. Record the failure. |
| 5 | Speech with music underneath | Music will mostly remain. That is expected. It is not a bug in v1. |
| 6 | A second person, or a television | The other voice remains. That is expected. It is not a bug in v1. |
| 7 | A whisper and a raised voice | The whisper is still intelligible. |
| 8 | Speech while a game and the video encoder are running | No crackles, and the game does not start dropping frames. |

Write the eight results down. That page is the only thing that authorises more work.

## When a plugin is worth writing

Write `voice_isolate_filter` only if test 3, 4 or 8 fails on a day you actually stream, and the failure matters.

Do not write it in order to "also have a plugin". OBS already runs RNNoise.

If the tests say the built-in filter is not enough:

- The plugin is still one eye icon and no sliders.
- The audio thread only copies samples into a ring and back. The model runs on another thread. If that thread falls behind, pass the original audio through and log it once. Never emit a gap.
- The first model to try is a speech enhancer that is legal to ship inside a GPL plugin (MIT or BSD). Check the licence of the exact version before writing code. RNNoise itself is the wrong choice here, because OBS already runs it.
- Expect some delay, on the order of tens of milliseconds. Measure it. If you listen to your own voice through OBS, that delay becomes an echo, and the plugin is the wrong tool. Use the script version instead.
- If OBS is running at 44.1 kHz and the model wants 48 kHz, resample in and out, and reset the model when the rate changes.

"My voice only" stays out. It needs a recording of you, it will reject you when you are tired or whispering, and it cannot separate two voices at the same time. Revisit it only after tests 1 to 4 are boring.

## What v1 will not do

- No strength knob
- No window of its own
- No cloud
- No promise about other people talking
- No plugin, unless the test page says the script failed a test you care about

## Open points, with a default so work is not blocked

| Question | Default if you do not answer |
|---|---|
| Is the streaming PC the one with the RTX card? | Irrelevant for v1. RNNoise does not use it. |
| Do you listen to your own voice through OBS? | Assume yes. That is why v1 stays on the built-in filter, which adds very little delay. |
| Which noise is the real problem: fan, keyboard, or other people? | Build for the fan. Keyboard is a recorded test, not a promise. Other people are out of v1. |
