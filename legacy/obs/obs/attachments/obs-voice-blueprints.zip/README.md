# OBS branch

This branch is the plan for two OBS tools. Nothing here is built yet.

The plan follows the matcher that already lives on `main`:

`implementation/matcher/match_voice.py`

That script is the maths that understands `implementation/presets/Zoom-H1n-Voice-Reference.json`. The OBS tools must use those same equations. They must not invent a new equaliser.

| File | What it is |
|---|---|
| [voice-match-blueprint.json](voice-match-blueprint.json) | App 1. Match tone, dynamics and loudness to the Zoom H1n profile. Three sliders. |
| [voice-isolation-blueprint.md](voice-isolation-blueprint.md) | App 2. One toggle. Keep speech, turn down the rest. |
| [opinions/](opinions/) | The notes supplied with the request. Opinions only. Not the spec. |

Chain order on a microphone, top to bottom:

1. Voice isolation
2. Voice match
3. Nothing else that changes gain, compression or limiting

Checked against OBS docs and OBS source on 2026-11-25. Facts that were not checked are marked in the two plan files.
