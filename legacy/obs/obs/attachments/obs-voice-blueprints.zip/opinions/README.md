# Opinions, not the spec

These three files came with the request. They are kept here so the discussion is not lost.

Do not build from them.

The spec is the two files in the parent folder. Where an opinion disagrees with `implementation/matcher/match_voice.py` on `main`, the matcher wins. The disagreements are listed in `voice-match-blueprint.json` under `rejected_from_the_opinion`.

`Zoom-H1n-Voice-Reference.json` is a copy of the profile. The canonical copy remains `implementation/presets/Zoom-H1n-Voice-Reference.json` on `main`. The upload name had a `.txt` suffix. The contents are JSON and were not edited.
