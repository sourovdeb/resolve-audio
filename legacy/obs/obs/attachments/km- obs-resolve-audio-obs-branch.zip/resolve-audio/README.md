# resolve-audio — OBS Branch

Two OBS audio tools that share one goal: make any microphone sound like the
**Zoom H1n voice reference** (`reference/Zoom-H1n-Voice-Reference.json`), and
keep only your voice when you toggle isolation on.

## The two apps

| | App 1: Voice Match | App 2: Voice Isolation |
|---|---|---|
| File | `blueprints/voice-match-blueprint.json` | `blueprints/voice-isolation-blueprint.md` |
| Job | Measure your mic, then use math (EQ curve fit, compression ratio solver, loudness control) to move its tone, dynamics and loudness onto the reference numbers | One toggle: keep speech, remove noise (fan, keyboard, hum). Optional later tier: only *your* enrolled voice |
| Form | OBS plugin (best quality) + Python script (quick first version) | OBS script toggle (first) + native plugin (second) |
| UI | Exactly 3 sliders: **Tone match** (default 80%), **Dynamics match** (default 70%), **Level** (default 0 dB) | No sliders. OBS's filter eye icon is the on/off switch |

## Chain order in OBS (both apps enabled)

1. Voice Isolation (App 2) — cleans the signal first
2. Voice Match (App 1) — measures and corrects on the clean signal
3. Remove OBS's own Gain / Compressor / Limiter from the same source (App 1 already includes them)

## Status

Blueprints only — no code written yet. Build order per the blueprints:
discovery inside OBS → offline analyser (Python) → script version →
native plugin → validation.

## Folders

- `blueprints/` — the two build plans (JSON for App 1, Markdown for App 2)
- `reference/` — the Zoom H1n measured voice profile (15 bands, loudness, spread)
- `attachments/` — the original uploaded files, unmodified
